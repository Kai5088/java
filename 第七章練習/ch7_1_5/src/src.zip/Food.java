public class Food
{
    public String name;
    public  void eat()
    {
    	System.out.print("eat food");
    }

}
