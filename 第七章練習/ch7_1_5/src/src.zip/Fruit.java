public class Fruit extends Food
{
	   public  void eat()
	    {
	    	System.out.print("eat food");
	    }

}