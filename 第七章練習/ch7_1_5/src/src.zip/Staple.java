public class Staple extends Food
{
	   public  void eat()
	    {
	    	System.out.println("eat food");
	    }

}