public class Staple extends Food
{
}