public class Apple extends Fruit
{
	   public  void eat()
	    {
	    	System.out.print("eat food");
	    }

}