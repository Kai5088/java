public class Food
{
    public String name;
    public  void eat()
    {
    	System.out.println("eat food");
    }

}
