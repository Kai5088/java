public class Rice extends Staple
{
}