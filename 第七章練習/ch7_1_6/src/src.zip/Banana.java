public class Banana extends Fruit
{
}